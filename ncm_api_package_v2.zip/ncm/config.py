# 全局配置
API_BASE_URL = "http://localhost:3002/"
#API_BASE_URL = "https://163.0061226.xyz/"
#API_BASE_URL = "http://192.168.101.6:3000/"
DEFAULT_SONG_ID = 1856336348
DEFAULT_BIT_RATE = 320000
COOKIE_FILE = "cookie.json"
GUEST_COOKIE_FILE = "cookie-guest.json"
